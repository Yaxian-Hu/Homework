#导入包
import seaborn
import scipy.stats
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from pylab import*
import matplotlib.pyplot as plot
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestRegressor

#导入数据
train=pd.read_csv(r'C:\Users\user\Desktop\GiveMeSomeCredit\cs-training.csv')  #训练集
test=pd.read_csv(r'C:\Users\user\Desktop\GiveMeSomeCredit\cs-test.csv')       #测试集


train.info()
pd.set_option('display.max_columns',2000)
pd.set_option('display.max_rows',2000)
print(train.head())
print(train.describe(include='all'))

#将变量名换为中文便于理解
states={
        'Unnamed: 0':'id',
        'SeriousDlqin2yrs':'好坏客户',
        'RevolvingUtilizationOfUnsecuredLines':'可用额度比值', 
        'age':'年龄',
        'NumberOfTime30-59DaysPastDueNotWorse':'逾期30-59天笔数',
        'DebtRatio':'负债率',
        'MonthlyIncome':'月收入',
        'NumberOfOpenCreditLinesAndLoans':'信贷数量',
        'NumberOfTimes90DaysLate':'逾期90天笔数',
        'NumberRealEstateLoansOrLines':'固定资产贷款量',
        'NumberOfTime60-89DaysPastDueNotWorse':'逾期60-89天笔数',
        'NumberOfDependents':'家属数量'
         } #创建字典

print(train.rename(columns=states,inplace=True))
print(train.head())


print("月收入缺失比：{:.2%}".format(train['月收入'].isnull().sum()/train.shape[0]))
print("家属数量缺失比：{:.2%}".format(train['家属数量'].isnull().sum()/train.shape[0]))

#填补月收入缺失值
def set_missing(df):
    
    process_df = df.iloc[:,[6,0,1,2,3,4,4,7,8,9,10]]
    
    known = process_df[process_df.月收入.notnull()].values
    unknown = process_df[process_df.月收入.isnull()].values
    
    X = known[:, 1:]
    
    y = known[:, 0]
    
    rfr = RandomForestRegressor(random_state=0, 
    n_estimators=200,max_depth=3,n_jobs=-1)
    rfr.fit(X,y)
    
    predicted = rfr.predict(unknown[:, 1:]).round(0)
    print(predicted)
    
    df.loc[(df.月收入.isnull()), '月收入'] = predicted
    return df

train=set_missing(train)

print("月收入缺失比：{:.2%}".format(train['月收入'].isnull().sum()/train.shape[0]))
print(train.head())



#删除存在缺失值的样本
train=train.dropna()
train.info()

#箱线图
fig=plt.figure(figsize=(15,10))
a=fig.add_subplot(3,2,1)
b=fig.add_subplot(3,2,2)
c=fig.add_subplot(3,2,3)
d=fig.add_subplot(3,2,4)
e=fig.add_subplot(3,2,5)
f=fig.add_subplot(3,2,6)

a.boxplot(train['可用额度比值'])
b.boxplot(train['好坏客户'])
c.boxplot([train['逾期30-59天笔数'],train['逾期60-89天笔数'],train['逾期90天笔数']])
d.boxplot([train['信贷数量'],train['固定资产贷款量'],train['家属数量']])
e.boxplot(train['月收入'])
f.boxplot(train['负债率'])



train=train[train['年龄']>0]

#去可用额度比值、负债率、月收入的除异常值 
for k in [2,3,5,6]: #遍历列 
    q1=train.iloc[:,k].quantile(0.25)  #计算上四分位数
    q3=train.iloc[:,k].quantile(0.75)  #计算下四分位数
    iqr=q3-q1
    low=q1-1.5*iqr
    up=q3+1.5*iqr
    if k==2:
        train1=train
    train1=train1[(train1.iloc[:,k]>low) & (train1.iloc[:,k]< up)]  #保留正常值范围
train=train1
train.info()

#分别去掉各变量的异常值
train=train[train['逾期30-59天笔数']<80]
train=train[train['逾期60-89天笔数']<80]
train=train[train['逾期60-89天笔数']<80]
train=train[train['逾期90天笔数']<80]
train=train[train['固定资产贷款量']<50]
train=train[train['家属数量']<15]


#去掉重复样本
train.drop_duplicates(inplace=True)
print(train.describe() )

# 画直方图
matplotlib.rcParams['font.sans-serif']=['SimHei']   # 用黑体显示中文
matplotlib.rcParams['axes.unicode_minus']=False     # 正常显示负号
train.hist(figsize=(20,15))

#相关系数
print(train.corr())


def op(y,x,n=20): #定义函数，有三个参数，x为要分箱的变量，y对应关注的因变量，即好坏客户，n最大分组数为20，依次减小试验
    r=0
    bad=y.sum()         #计算坏客户个数，因为等于1时表示坏客户，所以求和即可得到好客户数
    good=y.count()-bad   #count统计个数为所有客户数，减去好客户得到好客户人数
    while np.abs(r)<1:   #判断，当绝对值小于1时继续执行，直到相关系数绝对值等于1停止
        '''qcut根据这些值的频率来选择箱子的均匀间隔，
            https://blog.csdn.net/starter_____/article/details/79327997
                 即每个箱子中含有的数的数量是相同的实则为等深分段，x为数据，n是分组数，返回分组情况'''
        d1=pd.DataFrame({"x":x,"y":y,"bucket":pd.qcut(x,n)}) 
        d2=d1.groupby('bucket',as_index=True) #对数据框d1按照bucket变量分组，Ture则返回以组标签为索引的对象,reset_index()可以取消分组索引让其变成dataframe 
        r,p=scipy.stats.spearmanr(d2.mean().x,d2.mean().y)  #分组，数据为组间均值，计算此时x与y的斯皮尔曼等级相关系数，输出相关系数和P值
        n=n-1               #减小分组数
    d3=pd.DataFrame(d2.x.min(),columns=['min'])  #建立数据框
    d3['min']=d2.min().x
    d3['max']=d2.max().x
    d3['sum']=d2.sum().y #对应分组的坏客户数
    d3['total']=d2.count().y  #对应分组总客户数
    d3['rate']=d2.mean().y     #坏客户数占该组总人数比
    d3['woe']=np.log((d3['rate']/(1-d3['rate']))/(good/bad))   #求woe
    d4=(d3.sort_index(by='min')).reset_index(drop=True)
    print("="* 60)
    print(d4)
    return(d4)



#对于不能采用最优分段的变量采用等深分段

def funqcut(y,x,n):
    cut1=pd.qcut(x.rank(method='first'),n)  #进行等深分箱，分组
    
    data=pd.DataFrame({"x":x,"y":y,"cut1":cut1})
    cutbad=data.groupby(cut1).y.sum()   #求分组下的坏客户数
    cutgood=data.groupby(cut1).y.count()-cutbad #求分组下好客户数
    bad=data.y.sum() #求总的坏客户数
    good=data.y.count()-bad #求总的好客户数
    
    woe=np.log((cutbad/bad)/(cutgood/good)) #求各分组的woe
    iv=(cutbad/bad-cutgood/good)*woe  #求各分组的iv
    
    cut=pd.DataFrame({"坏客户数":cutbad,"好客户数":cutgood,"woe":woe,"iv":iv})
    print(cut)
    
    return cut#返回表格和对应分组列表

#funqcut(train['好坏客户'],train['年龄'],6).reset_index()

x1=funqcut(train['好坏客户'],train['可用额度比值'],5).reset_index()  
x2=funqcut(train['好坏客户'],train['年龄'],12).reset_index()
x4=funqcut(train['好坏客户'],train['负债率'],4).reset_index()  
x5=funqcut(train['好坏客户'],train['月收入'],5).reset_index()
x6=funqcut(train['好坏客户'],train['信贷数量'],6).reset_index()

'''qcut按照等频方式分箱，且要求分位点处的取值唯一。当有多个元素有相同的分位点处取值时，就会报错
添加.rank(method=‘first’)，相同取值元素的rank不同pd.qcut(df['a'].rank(method='first'), 10) '''

x3=funqcut(train['好坏客户'],train['逾期30-59天笔数'],5).reset_index()
x7=funqcut(train['好坏客户'],train['逾期90天笔数'],5).reset_index()
x8=funqcut(train['好坏客户'],train['固定资产贷款量'],5).reset_index() 
x9=funqcut(train['好坏客户'],train['逾期60-89天笔数'],5).reset_index()
x10=funqcut(train['好坏客户'],train['家属数量'],5).reset_index()

#画出各个变量的woe值变化情况
fig,axes=plt.subplots(4,3,figsize=(20,15))
x1.woe.plot(ax=axes[0,0],title="可用额度比值")
x2.woe.plot(ax=axes[0,1],title="年龄")
x3.woe.plot(ax=axes[0,2],title="逾期30-59天笔数")
x4.woe.plot(ax=axes[1,0],title="负债率")
x5.woe.plot(ax=axes[1,1],title="月收入")
x6.woe.plot(ax=axes[1,2],title="信贷数量")
x7.woe.plot(ax=axes[2,0],title="逾期90天笔数")
x8.woe.plot(ax=axes[2,1],title="固定资产贷款量")
x9.woe.plot(ax=axes[2,2],title="逾期60-89天笔数")
x10.woe.plot(ax=axes[3,0],title="家属数量")




'''根据前文，已经算出了各变量不同分组对应的IV值，现在利用上述公式计算自变量的IV值'''
ivx1=x1.iv.sum()
ivx2=x2.iv.sum()
ivx3=x3.iv.sum()
ivx4=x4.iv.sum()
ivx5=x5.iv.sum()
ivx6=x6.iv.sum()
ivx7=x7.iv.sum()
ivx8=x8.iv.sum()
ivx9=x9.iv.sum()
ivx10=x10.iv.sum()
IV=pd.DataFrame({"可用额度比值":ivx1,
                 "年龄":ivx2,
                 "逾期30-59天笔数":ivx3,
                 "负债率":ivx4,
                 "月收入":ivx5,
                 "信贷数量":ivx6,
                 "逾期90天笔数":ivx7,
                 "固定资产贷款量":ivx8,
                 "逾期60-89天笔数":ivx9,
                 "家属数量":ivx10},index=[0])

ivplot=IV.plot.bar(figsize=(15,10))
ivplot.set_title('特征变量的IV值分布')


#利用前文的等深分段分箱设定，将各个变量的分箱后情况保存为cut1,cut2，cut3...与所得到的分箱情况总结表相对应。其中采用x2/x4/x5采用最优分段的结果
def cutdata(x,n):
    a=pd.qcut(x.rank(method='first'),n,labels=False)#等深分组，label=False返回整数值（0,1,2,3...）对应第一类、第二类..
    return a
#连续变量均被等深分为了5类 

#应用函数，求出各变量分类情况 
cut1=cutdata(train['可用额度比值'],5)
cut2=cutdata(train['年龄'],12)
cut3=cutdata(train['逾期30-59天笔数'],5)
cut4=cutdata(train['负债率'],4)
cut5=cutdata(train['月收入'],5)
cut6=cutdata(train['信贷数量'],6)
cut7=cutdata(train['逾期90天笔数'],5)
cut8=cutdata(train['固定资产贷款量'],5)
cut9=cutdata(train['逾期60-89天笔数'],5)
cut10=cutdata(train['家属数量'],5)

print(cut1.head())

#依据变量值的分类替换成对应的woe值
def replace_train(cut,cut_woe):  #定义替换函数，cut为分组情况，cut_woe为分组对应woe值
    a=[]
    for i in cut.unique(): #unique为去重，保留唯一值
        a.append(i)
        a.sort()  #排序，默认小到大，得到类别列表并排序，实则为[0,1,2,3,4]
    for m in range(len(a)):
        cut.replace(a[m],cut_woe.values[m],inplace=True) #替换函数，把cut中旧数值a[m]即分类替换为对应woe,cut_woe中的woe也是从小到大排序，因此与a[m]对应，正如把cut中的0替换为woe值，没有改变cut的数值顺序
    return cut  #返回被替换后的列表

#应用上述函数进行数值替换，cut1,cut2...保存了变量分组，x1,x2..保存了woe、iv等值
train_new=pd.DataFrame() #创建新数据框保存替换后的新数据
train_new['好坏客户']=train['好坏客户']
train_new['可用额度比值']=replace_train(cut1,x1.woe)
train_new['年龄']=replace_train(cut2,x2.woe)
train_new['逾期30-59天笔数']=replace_train(cut3,x3.woe)
train_new['负债率']=replace_train(cut4,x4.woe)
train_new['月收入']=replace_train(cut5,x5.woe)
train_new['信贷数量']=replace_train(cut6,x6.woe)
train_new['逾期90天笔数']=replace_train(cut7,x7.woe)
train_new['固定资产贷款量']=replace_train(cut8,x8.woe)
train_new['逾期60-89天笔数']=replace_train(cut9,x9.woe)
train_new['家属数量']=replace_train(cut10,x10.woe)
print(train_new.head())

from sklearn.linear_model import LogisticRegression  
from sklearn.model_selection import train_test_split 

'''根据前文的变量选择分析，将负债率、月收入、信贷数量、
固定资产贷款量、家属数量变量舍弃，不纳入模型中'''
train_new1=train_new.drop(["负债率","月收入","信贷数量","固定资产贷款量","家属数量"],axis=1)
train_new1.head()

x=train_new1.iloc[:,1:] #设定自变量
y=train_new.iloc[:,0] #设定因变量

#将数据集进行切割，分成训练集和测试集，其中样本占比0.8，采用随机抽样 
train_x,test_x,train_y,test_y=train_test_split(x,y,train_size=0.8,random_state=4)

#建立模型
model=LogisticRegression()
result=model.fit(train_x,train_y) #训练模型，将结果保存为result
pred_y=model.predict(test_x)  #预测测试集的y
result.score(test_x,test_y)    #计算预测精度 正确率
print(result.score(test_x,test_y))

#利用sklearn.metrics计算ROC和AUC值
from sklearn.metrics import  roc_curve, auc  #导入函数
proba_y=model.predict_proba(test_x)  #预测概率predict_proba：
'''返回的是一个n行k列的数组，第i行第j列上的数值是模型预测第i个预测样本的标签为j的概率，此时每一行的和应该等于1。'''
fpr,tpr,threshold=roc_curve(test_y,proba_y[:,1])  #计算threshold阈值，tpr真正例率，fpr假正例率，大于阈值的视为1即坏客户
roc_auc=auc(fpr,tpr)   #计算AUC值

plt.plot(fpr,tpr,'b',label= 'AUC= %0.2f' % roc_auc) #生成roc曲线
plt.legend(loc='lower right')
plt.plot([0,1],[0,1],'r--')
plt.xlim([0,1])
plt.ylim([0,1])
plt.ylabel('真正率')
plt.xlabel('假正率')
plt.show()
print(roc_auc)
